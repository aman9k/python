from django.apps import AppConfig


class ArsAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ARS_app'
