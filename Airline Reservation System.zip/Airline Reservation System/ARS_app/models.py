from unittest.util import _MAX_LENGTH
from django.db import models

# Create your models here.

class weather:
    city1:str
    city2:str
    city3:str

class test(models.Model):
    name = models.CharField(max_length=100)
    name_1 = models.CharField(max_length=100)
    desc = models.TextField()
    price = models.IntegerField()
    