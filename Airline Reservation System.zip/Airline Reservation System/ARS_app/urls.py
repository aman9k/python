
from operator import index
# from django.contrib import admin
from django.urls import path
from ARS_app import views

# from django.urls import path, include

urlpatterns = [
    path('',views.index,name='index'),
    path('contact/', views.contact, name = 'contact'),
    path('logSign/', views.logSign, name = 'logSign'),
    # path('register/',include('accounts.urls'))


]

