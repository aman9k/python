from django.shortcuts import render, HttpResponse
from .models import weather
# Create your views here.



def index(request):
    wh = weather()
    wh.city1 = 'Mumbai'
    wh.city2 = 'Delhi'
    wh.city3 = 'Kolkata'
    return render(request,"index.html",{'wh':wh})
    # return HttpResponse('Home Page')

def logSign(request):
    return render(request, "logSign.html") 

def contact(request):
    return render(request, 'contact.html') 
    






